package conectores;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conector {
    private static String driver="com.mysql.cj.jdbc.Driver";    
    private static String vendor="mysql";
    private static String server="127.0.0.1";
    private static String port="3307";
    private static String db="biblioteca";
    private static String params="?serverTimezone=UTC";
    private static String user="root";
    private static String pass="";
    
    
    
    private static String url="jdbc:"+vendor+"://"+server+":"+port+"/"+db+params;
    
    private static Connection conn=null;
    
    private Conector(){ }
    
    public synchronized static Connection getConnection(){
        try{
            if(conn==null || conn.isClosed()){
                Class.forName(driver);
                conn=DriverManager.getConnection(url, user, pass);
            }
        }catch(SQLException e) {System.out.println("Problema de conexión");
        }catch(ClassNotFoundException e) { System.out.println("No se encontro el driver");
        }catch(Exception e){ e.printStackTrace(); }
        return conn;
    }
    
    
    
    
    
    
    
    
    
    
}





