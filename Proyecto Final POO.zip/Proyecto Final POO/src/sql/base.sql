drop database if exists biblioteca;
create database biblioteca;
use biblioteca;
drop table if exists Empleado;
drop table if exists Cliente
drop table if exists Libro;
drop table if exists Editorial;
create table Empleado(
    id int auto_increment primary key,
    nombre varchar(25) null,
    direccion varchar(30) null,
    salario double(10,2),
    FOREIGN KEY (id) refereces Cliente(id)
);

create table Cliente(
    id int auto_increment primary key,
    nombre varchar(25) null,
    apellido varchar (25) ull,
    edad int(2),
    FOREIGN KEY (id) references Empleado(id)
);

create table Libro(
    nombre varchar(25),
    autor varchar(25),
    paginas int(150)
);

create table Editorial(
    nombre varchar(25),
    direccion varchar(100),
    telefono varchar(15)
);














