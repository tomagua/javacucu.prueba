
package blb;


import entidades.Libro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Impl implements Libro{
    
    private Connection conn;

    public Implo(Connection conn) {
        this.conn = conn;
    }

    public void crearProducto(Libro producto) {
        String query = "INSERT INTO libros (nombre, autor, paginas) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getAutor());
            ps.setInt(3, producto.getPaginas());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Libro buscarLibroPorNombre(String nombre) {
        Libro libro = null;
        String query = "SELECT * FROM libros WHERE nombre = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, nombre);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String libroDB = rs.getString("nombre");
                String autor = rs.getString("autor");
                int paginas = rs.getInt("paginas");
                double precio = rs.getDouble("precio");
                int stock = rs.getInt("stock");
                libro = new Libro(nombre, autor, paginas);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return libro;
    }

    public List<Libro> listarLibros() {
        List<Libro> libros = new ArrayList<>();
        String query = "SELECT * FROM libros";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String autor = rs.getString("autor");
                int paginas = rs.getInt("paginas");
                Libro libro = new Libro(nombre, autor, paginas);
                libros.add(libro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return libros;
    }

    public void actualizarLibro(Libro libro) {
        String query = "UPDATE libros SET nombre = ?, autor = ?, paginas = ? WHERE nombre = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, libro.getNombre());
            ps.setString(2, libro.getAutor());
            ps.setInt(3, libro.getPaginas());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminarLibro(Libro libro) {
        String query = "DELETE FROM libros WHERE nombre = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, libro.getNombre());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertarLibro(Libro nuevoLibro) {
        crearLibro(nuevoLibro);
    }

    private void crearLibro(Libro nuevoLibro) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}


