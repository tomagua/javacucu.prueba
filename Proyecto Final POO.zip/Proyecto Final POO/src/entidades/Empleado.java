package entidades;

public class Empleado {

    private int id;
    private String nombre;
    private String direccion;
    private double salario;

    public Empleado() {}

    public Empleado(String nombre, String direccion, double salario) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.salario = salario;
    }
    
    
    

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }


    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Empleado " + "nombre = " + nombre + ", direccion = " + direccion + ", salario = " + salario;
    }
    
}
